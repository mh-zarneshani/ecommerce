@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set "PYTHONIOENCODING=utf-8"
set "PYTHONDONTWRITEBYTECODE=1"
call "%~dp0Ensure-Windows-Python.cmd"
if errorlevel 1 goto finish
"%ECOM_PY%" launch.py --probe-gapgpt
:finish
set "CHECK_RESULT=%ERRORLEVEL%"
pause
exit /b %CHECK_RESULT%
