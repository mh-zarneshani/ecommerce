"""Run the entire suite in a private scratch cluster using installed PostgreSQL binaries."""
import argparse
import json
import os
from pathlib import Path
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile

from psycopg.conninfo import make_conninfo

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import setup_local

def binaries(explicit):
    exe='initdb.exe' if os.name=='nt' else 'initdb'
    options=[Path(p) for p in (explicit,os.getenv('PGBIN')) if p]
    if init:=shutil.which(exe):
        options.append(Path(init).parent)
    if pg:=shutil.which('pg_config'):
        options.append(Path(subprocess.check_output([pg,'--bindir'],text=True).strip()))
    if os.name=='nt':
        options.extend(p/'bin' for p in sorted((Path(os.getenv('ProgramFiles','C:/Program Files'))/
                        'PostgreSQL').glob('*'),reverse=True))
    else:
        options.extend(sorted(Path('/usr/lib/postgresql').glob('*/bin'),reverse=True))
    for p in options:
        if (p/exe).is_file():
            return p
    raise SystemExit('PostgreSQL binaries not found. Supply --pg-bin.')

def main():
    cli=argparse.ArgumentParser()
    cli.add_argument('--pg-bin')
    cli.add_argument('pytest_args',nargs=argparse.REMAINDER)
    a=cli.parse_args()
    bin_dir=binaries(a.pg_bin)
    suffix='.exe' if os.name=='nt' else ''
    def run(name,*args,**kwargs):
        return subprocess.run([str(bin_dir/(name+suffix)),*map(str,args)],check=True,**kwargs)
    with tempfile.TemporaryDirectory(prefix='.qa-run-',dir=ROOT) as scratch:
        p=Path(scratch)
        setup_local.protect_dir(p)
        data,secret_file,log=p/'pg',p/'pw',p/'postgres.log'
        password=secrets.token_urlsafe(32)
        secret_file.write_text(password,encoding='ascii')
        try:
            run('initdb','-D',data,'-U','qa_admin','-A','scram-sha-256','--pwfile',secret_file,
                '-E','UTF8','--no-locale',stdout=subprocess.DEVNULL)
        finally:
            secret_file.unlink(missing_ok=True)
        with socket.socket() as s:
            s.bind(('127.0.0.1',0))
            port=s.getsockname()[1]
        try:
            run('pg_ctl','-D',data,'-l',log,'-o',f'-h 127.0.0.1 -p {port}','-w','start')
            setup_local.BASE=p/'profile'
            setup_local.PROFILE=setup_local.BASE/'postgres.json'
            setup_local.provision(port,'qa_admin',password)
            profile=json.loads(setup_local.PROFILE.read_text('utf-8'))
            env=dict(os.environ,ECOM_DSN=make_conninfo(**profile['app']),ECOM_TEST_DSN=make_conninfo(**profile['test']),
                     PYTHONIOENCODING='utf-8',STREAMLIT_BROWSER_GATHER_USAGE_STATS='false')
            args=a.pytest_args
            if args[:1]==['--']: args=args[1:]
            return subprocess.call([sys.executable,'-m','pytest',*args],env=env,cwd=ROOT)
        finally:
            if (data/'postmaster.pid').exists():
                run('pg_ctl','-D',data,'-m','fast','-w','stop')

if __name__=='__main__':
    sys.exit(main())
