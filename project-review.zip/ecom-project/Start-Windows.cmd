@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
call "%~dp0Ensure-Windows-Python.cmd"
if errorlevel 1 goto failed
if exist "%LOCALAPPDATA%\ActiveEcomBootcamp\postgres.json" goto launch
call "%~dp0Setup-Windows.cmd" --from-start
if errorlevel 1 goto failed
if not exist "%LOCALAPPDATA%\ActiveEcomBootcamp\postgres.json" goto failed
:launch
"%ECOM_PY%" launch.py %*
if errorlevel 1 goto failed
exit /b 0
:failed
echo Could not start the app. Review the message above.
pause
exit /b 1
