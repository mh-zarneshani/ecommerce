@echo off
rem Run via CALL; return ECOM_PY to the calling script.
set "ECOM_PY="
call :use ".venv\Scripts\python.exe"
if defined ECOM_PY goto ready
call :use ".venv-win311\Scripts\python.exe"
if defined ECOM_PY goto ready
py -3.11 -c "import sys; assert sys.version_info[:2] == (3,11) and sys.version_info.releaselevel == 'final'" >nul 2>nul
if not errorlevel 1 goto create_with_py
python -c "import sys; assert sys.version_info[:2] == (3,11) and sys.version_info.releaselevel == 'final'" >nul 2>nul
if errorlevel 1 (
    echo Python 3.11 is required for the tested Windows launcher. Install Python 3.11, then try again.
    exit /b 1
)
python -m venv ".venv-win311"
goto created
:create_with_py
py -3.11 -m venv ".venv-win311"
:created
if errorlevel 1 exit /b 1
call :use ".venv-win311\Scripts\python.exe"
if not defined ECOM_PY exit /b 1
:ready
"%ECOM_PY%" -c "import openpyxl, psycopg, streamlit, httpx" >nul 2>nul
if not errorlevel 1 exit /b 0
"%ECOM_PY%" -m pip install --disable-pip-version-check -r requirements.txt
if errorlevel 1 exit /b 1
"%ECOM_PY%" -c "import openpyxl, psycopg, streamlit, httpx"
exit /b %ERRORLEVEL%

:use
if not exist "%~1" exit /b 0
"%~1" -c "import sys; assert sys.version_info[:2] == (3,11) and sys.version_info.releaselevel == 'final'" >nul 2>nul
if not errorlevel 1 set "ECOM_PY=%~f1"
exit /b 0
