# Build prompt — run first
Implement the repo's `spec.md` under `AGENTS.md`. Read the acceptance table once and reuse its IDs. Deliver working files and run commands; do not stop after planning. Inspect existing manifests and changed files. If the repo is empty, use the specified default stack.

Before implementation, author `inputs/class-demo.json` and independent `qa/golden.json` (test-only) if absent. For اکالا use 800/1000 category performance plus a fresh stockout in one Tehran store; for اسنپ use the same SKU, reference 100000 and observed 75000 تومان vs 20% cap. Freeze separate orderable/fetch-error branches. For workbook D1 freeze row count / net packs / monthly target / spend تومان: دیجی‌کالا 45/2416/5175/31399320; اکالا 45/2158/4830/26031144; اسنپ 45/2069/4485/26823336. Discount-support budget: 63250000 تومان for دیجی‌کالا; 57500000 تومان each for اکالا and اسنپ. Never generate goldens from actual app output.

1. Land a vertical slice: ingest the class checkpoint → compute metrics → open both cases → investigate → show ranked queue, with a focused test.
2. Complete the three-account workbook import and D1/D2 reconciliation, manual entry for all three, and the offline X1 source-reader contract check. Do not implement live store access. Keep workbook and class namespaces isolated. The `qa/` folder is for tests only.
3. Wire human actions, both observation branches, persistent audit and bounded model/offline tool loops. Use the supplied runtime prompt, not a second copy embedded in code. Exercise the UI paths; finish edge cases.
4. Implement the online DeepSeek adapter and access-controlled VPS deployment templates per spec §6. All routine tests are free/offline; never request credentials or deploy without the operator. Report the real VPS/provider smoke separately (H2).
5. Run the acceptance checks, fixed baseline comparison and warm-read measurements. Write the short app README and `reports/acceptance.md`. Fix failures without widening scope.

Work in one session unless blocked; no separate architecture essay or generated progress log. End with launch/test commands, demo clicks, pass/fail/not-run and material caveats. If incomplete, give the next failing check and how to reproduce it.
