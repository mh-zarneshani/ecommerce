@echo off
call "%~dp0Start-Windows.cmd" --avalai-demo %*
exit /b %ERRORLEVEL%
