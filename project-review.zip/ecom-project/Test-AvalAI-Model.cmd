@echo off
setlocal
cd /d "%~dp0"
set "PYTHONDONTWRITEBYTECODE=1"
call "%~dp0Ensure-Windows-Python.cmd"
if errorlevel 1 goto finish
"%ECOM_PY%" "%~dp0probe_avalai.py" --windows-dialog
:finish
set "CHECK_RESULT=%ERRORLEVEL%"
pause
exit /b %CHECK_RESULT%
