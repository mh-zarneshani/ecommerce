@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
call "%~dp0Ensure-Windows-Python.cmd"
if errorlevel 1 goto finish
powershell -NoProfile -Command "$svc=@(Get-CimInstance Win32_Service | Where-Object { $_.Name -match 'postgres' -and $_.State -eq 'Running' } | Select-Object -ExpandProperty ProcessId); $p=@(Get-CimInstance Win32_Process -Filter 'Name=''postgres.exe''' | Where-Object { $svc -contains $_.ParentProcessId } | Select-Object -ExpandProperty ProcessId); $ports=@(netstat -ano -p tcp | ForEach-Object { if ($_ -match '^\s*TCP\s+\S+:(\d+)\s+\S+\s+LISTENING\s+(\d+)\s*$' -and $p -contains [int]$Matches[2]) { $Matches[1] } } | Sort-Object -Unique); if ($ports.Count -eq 1) { & $env:ECOM_PY setup_local.py --port $ports[0] } else { & $env:ECOM_PY setup_local.py }"
:finish
set "RESULT=%ERRORLEVEL%"
if /I not "%~1"=="--from-start" pause
exit /b %RESULT%
