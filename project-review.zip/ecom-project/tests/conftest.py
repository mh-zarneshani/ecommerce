import pytest

import store

@pytest.fixture
def db():
    with store.connect(test=True) as c:
        if c.info.dbname != 'active_ecom_workshop_test':
            pytest.fail('Use the dedicated active_ecom_workshop_test database, never the app DB.')
        store.initialize(c)
        c.execute('truncate cases, triage_state, conflicts, records, model_budget')
        yield c

