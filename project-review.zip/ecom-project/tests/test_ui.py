"""Drive actual Streamlit widgets against the isolated PostgreSQL test database."""
import json
from pathlib import Path
import httpx
import streamlit as st
from streamlit.testing.v1 import AppTest
import pytest

from domain import Input, Sale, clock
import planner
import store
import triage

APP = Path(__file__).parents[1] / 'app.py'
DATA='گزارش‌ها و سوابق'
DASH='داشبورد'
MANUAL='ثبت و اصلاح فروش'
DESK='میز پیگیری'
DEMO='دموی ساختگی کلاس'
SETTINGS='تنظیمات'
M='بهمن'
A='ACC-DIGI'
CONFIRM='خلاصه و پرسش بالا را بررسی کردم و هزینهٔ همین درخواست را تأیید می‌کنم.'

def by_label(items,label):
    return next(x for x in items if x.label==label)

@pytest.fixture
def start_ui(db,monkeypatch):
    from psycopg.conninfo import make_conninfo
    args,config=store.config(test=True)
    monkeypatch.setenv('ECOM_DSN',make_conninfo(*args,**config))
    for k in ('HOSTED','AGENT_MODE','SLICE_AGENT','DEEPSEEK_API_KEY','GAPGPT_API_KEY'):
        monkeypatch.delenv(k,raising=False)
    st.cache_resource.clear()
    return lambda:AppTest.from_file(str(APP),default_timeout=30).run()

def click(ui,label):
    by_label(ui.button,label).click().run()
    assert not ui.exception and not ui.error

def select(ui,label,value):
    by_label(ui.selectbox,label).set_value(value).run()
    assert not ui.exception and not ui.error

def radio(ui,label,value):
    by_label(ui.radio,label).set_value(value).run()
    assert not ui.exception and not ui.error

def page(ui,name):
    radio(ui,'نمای برنامه',name)

def open_demo(ui):
    page(ui,DESK)
    radio(ui,'مجموعهٔ پرونده‌ها',DEMO)


@pytest.mark.parametrize('from_launcher',[False,True])
def test_local_avalai_form_requires_consent_and_uses_only_demo(db,start_ui,monkeypatch,from_launcher):
    get_option=st.get_option
    monkeypatch.setattr(st,'get_option',lambda name:'127.0.0.1' if name=='server.address' else get_option(name))
    sent=[]
    secret='aa-test-only-local'
    if from_launcher:
        monkeypatch.setenv('ECOM_LOCAL_AVALAI_BASE_URL','https://api.avalai.ir/v1')
        monkeypatch.setenv('ECOM_LOCAL_AVALAI_TOKEN',secret)

    def respond(request):
        sent.append(request)
        return httpx.Response(401,json={'private':secret})

    client=httpx.Client
    def mock_client(**kwargs):
        assert kwargs['verify'] and not kwargs['trust_env'] and not kwargs['follow_redirects']
        return client(transport=httpx.MockTransport(respond),**kwargs)

    monkeypatch.setattr(planner.httpx,'Client',mock_client)
    ui=start_ui()
    page(ui,SETTINGS)
    save='ثبت تنظیمات برای این نشست'
    ui.text_input(key='avalai_base_input').set_value('https://api.avalai.ir.evil.invalid/v1')
    ui.text_input(key='avalai_token_input').set_value(secret)
    by_label(ui.button,save).click().run()
    assert ui.error and not sent
    if not from_launcher:
        ui.text_input(key='avalai_base_input').set_value('https://api.avalai.ir/')
        ui.text_input(key='avalai_token_input').set_value(secret)
        click(ui,save)
    else:
        ui.run()
    open_demo(ui)
    start='آغاز دمو'
    assert by_label(ui.button,start).proto.disabled and not sent
    ui.checkbox(key='avalai_paid_consent').check().run()
    assert not sent
    click(ui,start)
    assert sent
    for request in sent:
        assert str(request.url)=='https://api.avalai.ir/v1/chat/completions'
        assert request.headers['authorization']==f'Bearer {secret}'
        body=json.loads(request.content)
        assert body['model']==planner.AVALAI_MODEL and body['tools']
        assert body['max_completion_tokens']==600 and secret not in request.content.decode()
    assert db.execute('select count(*) as n from cases where body::text like %s',('%'+secret+'%',)).fetchone()['n']==0
    count=len(sent)
    page(ui,SETTINGS)
    click(ui,'پاک کردن تنظیمات آوال‌ای‌آی')
    open_demo(ui)
    assert not any(c.key=='avalai_paid_consent' for c in ui.checkbox) and len(sent)==count

def net(ui):
    assert ui.radio(key='page').value==DASH
    return by_label(ui.metric,'فروش خالص').value

def scope(ui,label):
    assert any(label in item.value for item in ui.markdown)

def open_history(ui,day=15,hour=18):
    page(ui,DATA)
    select(ui,'اکانت اکسل',A)
    select(ui,'تاریخ موجود در اکسل',(M,day))
    select(ui,'ساعت برش',hour)
    click(ui,'نمایش داشبورد')

def rows(db):
    return db.execute('select source, count(*) n from records group by source order by source').fetchall()

def test_v3_four_step_read_only_navigation_and_persistence(db,start_ui):
    ui=start_ui()
    assert not ui.exception and ui.radio(key='page').value==DASH
    assert MANUAL in ui.radio(key='page').options
    page(ui,DATA)
    assert not ui.metric and not any(b.label=='نمایش داشبورد' for b in ui.button)
    assert any('وارد نشده' in x.value for x in ui.info)
    click(ui,'ورود اکسل آموزشی')
    before=rows(db)
    assert '۱۶ بهمن' not in by_label(ui.selectbox,'تاریخ موجود در اکسل').options
    open_history(ui)
    scope(ui,'دیجی‌کالا | ۱۵ بهمن | ساعت ۱۸:۰۰ | فقط اکسل')
    assert net(ui)=='۲٬۴۱۶' and rows(db)==before
    assert not any(b.label=='ورود اکسل آموزشی' for b in ui.button)

    page(ui,MANUAL)
    assert len(by_label(ui.selectbox,'اکانت ثبت').options)==3
    assert by_label(ui.selectbox,'روز ثبت').value==16
    assert by_label(ui.selectbox,'محصول ثبت').value=='PRD-CLEAR-450G'
    by_label(ui.number_input,'ثبت‌شده (بسته)').set_value(20)
    assert by_label(ui.number_input,'لغو (بسته)').value==by_label(ui.number_input,'مرجوع (بسته)').value==0
    click(ui,'ثبت فروش فرضی')
    scope(ui,'دیجی‌کالا | ۱۶ بهمن | ساعت ۱۸:۰۰ | اکسل + ثبت دستی')
    assert net(ui)=='۲٬۴۳۶'
    page(ui,MANUAL)
    click(ui,'ذخیرهٔ اصلاح')
    assert net(ui)=='۲٬۴۳۶'
    page(ui,MANUAL)
    by_label(ui.number_input,'ثبت‌شده (بسته)').set_value(18)
    click(ui,'ذخیرهٔ اصلاح')
    assert any('تأیید' in msg.value for msg in ui.warning)
    by_label(ui.checkbox,'اصلاح همین ردیف را تأیید می‌کنم').check()
    click(ui,'ذخیرهٔ اصلاح')
    assert net(ui)=='۲٬۴۳۴' and rows(db)[0]=={'source':'manual','n':2}
    select(ui,'منبع فروش',False)
    click(ui,'اعمال محدوده')
    assert net(ui)=='۲٬۴۱۶'
    scope(ui,'دیجی‌کالا | ۱۶ بهمن | ساعت ۱۸:۰۰ | فقط اکسل')

    before=rows(db)
    open_history(ui)
    assert net(ui)=='۲٬۴۱۶'
    scope(ui,'دیجی‌کالا | ۱۵ بهمن | ساعت ۱۸:۰۰ | فقط اکسل')
    preview=json.loads(ui.code[0].value)
    assert preview['خلاصه']['برش']=={'ماه':'بهمن','روز':15,'ساعت':'18:00'}
    assert preview['خلاصه']['شاخص‌ها']['فروش خالص (بسته)']==2416
    page(ui,DASH)
    assert net(ui)=='۲٬۴۱۶' and rows(db)==before

    ui=start_ui()
    page(ui,MANUAL)
    assert by_label(ui.number_input,'ثبت‌شده (بسته)').value==18
    click(ui,'ذخیرهٔ اصلاح')
    assert net(ui)=='۲٬۴۳۴'
    open_history(ui)
    assert net(ui)=='۲٬۴۱۶'

def test_v3_deepseek_preview_consent_paid_click_and_cutoff(db,start_ui,monkeypatch):
    producer_at=clock(M,15,16); arrives=clock(M,15,19)
    rec=Input('sale','DO-NOT-SEND-ID',1,A,producer_at,arrives,
              Sale(M,15,'PRD-CLEAR-450G',100,0,0,100000,0,0),{'raw':'DO-NOT-SEND-RAW'})
    store.import_book(db)
    store.ingest(db,'workbook','xlsx',type('Delayed',(),{'read':lambda self:[rec]})())
    monkeypatch.setenv('SLICE_AGENT','deepseek')
    monkeypatch.setenv('GAPGPT_API_KEY','placeholder-test-secret')
    sent=[]
    def send(key,body,timeout):
        assert key=='placeholder-test-secret' and 0 < timeout <= 20
        sent.append(body)
        return {'choices':[{'finish_reason':'stop','message':{'role':'assistant','content':'{"focus":"sales"}'}}]}
    monkeypatch.setattr(planner,'gapgpt_transport',send)
    ui=start_ui()
    open_history(ui)
    assert net(ui)=='۲٬۴۱۶'
    reviewed=ui.code[0].value
    payload=json.loads(reviewed)
    assert payload['خلاصه']['شاخص‌ها']['هدف وزنی تا برش (بسته)']=='2808.4'
    assert payload['خلاصه']['پوشش داده']['تعداد ردیف اکسل']==45
    ui.run()
    assert by_label(ui.button,'ارسال به DeepSeek').proto.disabled and not sent
    by_label(ui.checkbox,CONFIRM).check().run()
    assert not sent
    click(ui,'ارسال به DeepSeek')
    assert len(sent)==1 and sent[0]['messages'][-1]=={'role':'user','content':reviewed}
    assert sent[0]['model']=='gapgpt-deepseek-v4.1-flash'
    assert set(sent[0])=={'model','messages','max_tokens'} and sent[0]['max_tokens']==512
    serialized=json.dumps(sent)
    for absent in ('DO-NOT-SEND-ID','DO-NOT-SEND-RAW','placeholder-test-secret','dbname','SALE-'):
        assert absent not in serialized
    assert any('علت اختلاف را ثابت نمی‌کند' in t.value for t in ui.text)
    ui.run()
    page(ui,DASH)
    assert net(ui)=='۲٬۴۱۶'
    assert len(sent)==1
    open_history(ui,hour=19)
    assert net(ui)=='۲٬۵۱۶'
    preview=json.loads(ui.code[0].value)['خلاصه']
    assert preview['برش']['ساعت']=='19:00' and preview['شاخص‌ها']['فروش خالص (بسته)']==2516
    assert not ui.text and len(sent)==1
    assert by_label(ui.button,'ارسال به DeepSeek').proto.disabled
    select(ui,'نقش شبیه‌سازی محلی','observer')
    assert not any(b.label=='ارسال به DeepSeek' for b in ui.button)
    assert MANUAL not in ui.radio(key='page').options
    assert not ui.exception and len(sent)==1
    page(ui,SETTINGS)
    assert not any(t.key=='avalai_token_input' for t in ui.text_input)
    by_label(ui.checkbox,'نمایش دستیار در داشبورد فروش').uncheck().run()
    page(ui,DASH)
    assert not ui.code
    select(ui,'نقش شبیه‌سازی محلی','manager')
    open_demo(ui)
    click(ui,'آغاز دمو')
    assert len(sent)==1 and all(c['drafts'][-1]['mode']=='offline' for c in triage.cases(db))

def test_gapgpt_partial_error_shows_status_without_retry(db,start_ui,monkeypatch):
    import httpx

    store.import_book(db)
    monkeypatch.setenv('SLICE_AGENT','deepseek')
    monkeypatch.setenv('GAPGPT_API_KEY','placeholder-test-secret')
    sent=[]
    class Partial(httpx.SyncByteStream):
        def __iter__(self):
            raise httpx.RemoteProtocolError('private payload')
            yield b''
    def handle(request):
        sent.append(str(request.url))
        return httpx.Response(400,stream=Partial())
    monkeypatch.setattr(planner,'_gapgpt_client',lambda timeout:httpx.Client(
        timeout=timeout,transport=httpx.MockTransport(handle)))

    ui=start_ui()
    open_history(ui)
    by_label(ui.checkbox,CONFIRM).check().run()
    assert not sent
    by_label(ui.button,'ارسال به DeepSeek').click().run()
    assert any('HTTP 400' in e.value and 'ناقص' in e.value for e in ui.error)
    assert not ui.exception and not ui.text
    ui.run()
    click(ui,'آماده‌سازی تلاش دوباره')
    assert by_label(ui.button,'ارسال به DeepSeek').proto.disabled
    assert len(sent)==1 and not ui.exception


def test_p1_class_paths_remain_separate(db,start_ui):
    ui=start_ui()
    do_click=lambda label:click(ui,label)
    choose=lambda label,value:select(ui,label,value)
    open_demo(ui)
    do_click('آغاز دمو')
    assert len(ui.metric)==2 and len(triage.queue(db))==2
    by_label(ui.text_area,'متن ارجاع داخلی').set_value('مسئول فروشگاه شاهد تازه را بررسی کند.')
    do_click('ذخیرهٔ متن اصلاحی')
    do_click('تأیید و ایجاد ارجاع داخلی')
    do_click('دوباره قابل سفارش شد')
    radio(ui,'پرونده','CASE-00001')
    assert not any(b.label=='بستن پرونده توسط مسئول' for b in ui.button)
    choose('نقش شبیه‌سازی محلی','specialist')
    do_click('بستن پرونده توسط مسئول')
    assert triage._case(db,triage.DEMO,'CASE-00001')['status']=='closed'
    choose('نقش شبیه‌سازی محلی','manager')
    do_click('بازنشانی فقط دموی ساختگی')
    do_click('آغاز دمو')
    radio(ui,'پرونده','CASE-00001')
    do_click('رد پیشنهاد')
    do_click('دریافت اطلاعات خطا داد')
    radio(ui,'پرونده','CASE-00001')
    c=triage._case(db,triage.DEMO,'CASE-00001')
    assert c['status']=='open' and not c['referrals'] and c['latest']['status']=='error'
    assert not any(b.label=='بستن پرونده توسط مسئول' for b in ui.button)

