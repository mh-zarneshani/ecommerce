"""PostgreSQL regression carried forward from the starter's account/overlay test."""
from decimal import Decimal as D
import json
from pathlib import Path
import subprocess
import sys

import store
from domain import PRODUCTS

GOLD=json.loads((Path(__file__).parents[1]/'qa/golden.json').read_text(encoding='utf-8'))
M='بهمن'
P=next(iter(PRODUCTS))

def test_d1_and_three_account_manual_persistence(db):
    assert store.metrics(db,M,15,'ACC-DIGI')['net'] is None
    counts,reasons=store.import_book(db)
    assert counts['sale:new']==1215
    assert not reasons
    initial=store.import_book(db)[0]
    assert initial['sale:duplicate']==1215 and initial['plan:duplicate']==18
    for a,(rows,net,target,spend,budget) in GOLD['workbook'].items():
        x=store.metrics(db,M,15,a)
        assert [len(x['rows']),x['net'],x['target'],x['spend'],x['budget']]==[rows,net,target,spend,budget]
        assert (x['attain'],x['util'],x['fraction'])==(D(net)/target,D(spend)/budget,D('17.8')/D('32.8'))
        assert store.metrics(db,M,16,a,True)['missing']==3
        vals=(20,0,0,100000,0,0)
        assert store.save_manual(db,M,16,a,P,vals,0)=='new'
        assert store.metrics(db,M,16,a,True)['net']==net+20
        assert store.save_manual(db,M,16,a,P,vals,0)=='duplicate'
        assert store.metrics(db,M,16,a,True)['net']==net+20
        assert store.save_manual(db,M,16,a,P,(18,*vals[1:]),1,True)=='corrected'
        assert store.save_manual(db,'اسفند',29,a,P,(0,*vals[1:]),0)=='new'
        x=store.metrics(db,'اسفند',29,a,True)
        assert x['net']==0 and x['attain']==0 and x['missing']==86
    program="""import store
import json
with store.connect(test=True) as db:
    print(json.dumps([[store.metrics(db,'بهمن',16,a,o)['net'] for o in (True,False)] for a in store.ACCOUNTS]))
"""
    result=json.loads(subprocess.check_output([sys.executable,'-X','utf8','-c',program]))
    assert result==[[2434,2416],[2176,2158],[2087,2069]]
    assert db.execute("select count(*) n from records where source='manual' and kind='sale'").fetchone()['n']==9

