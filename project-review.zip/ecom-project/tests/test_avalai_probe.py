import json

import httpx
import pytest

import probe_avalai


@pytest.mark.parametrize('answer',['','send','CANCEL'])
def test_cancel_never_reads_key_or_builds_client(monkeypatch,answer):
    monkeypatch.setattr('builtins.input',lambda _:answer)
    monkeypatch.setattr(probe_avalai.getpass,'getpass',lambda _:pytest.fail('read key'))
    monkeypatch.setattr(httpx,'Client',lambda **_:pytest.fail('created client'))
    assert probe_avalai.main()==0


@pytest.mark.parametrize('status,expected',[(200,'PASS'),(400,'Request rejected.'),(307,'No successful completion.')])
@pytest.mark.parametrize('pasted',[
    'aa-test-placeholder',
    '\ufeff  "Bearer aa-test-placeholder"  ',
    "authorization:\tbeAREr 'aa-test-placeholder'",
    '\u200f«aa-test-placeholder»\u00a0\u200e',
])
def test_one_request_only_to_avalai(monkeypatch,capsys,status,expected,pasted):
    calls=[]
    def handle(request):
        calls.append(request)
        return httpx.Response(status,headers={
            'avalai-request-id':'01a009d5-ec91-74c2-8ffa-9eba731dfc9e',
            'Location':'https://example.invalid/',
            'x-private':'private-header',
        },json={'choices':[{'message':{'content':'private-body'}}]})
    real_client=httpx.Client
    def client(**opts):
        assert opts==dict(timeout=60,verify=True,trust_env=False,follow_redirects=False)
        return real_client(transport=httpx.MockTransport(handle),**opts)
    monkeypatch.setattr('builtins.input',lambda _:'SEND')
    monkeypatch.setattr(probe_avalai.getpass,'getpass',lambda _:pasted)
    monkeypatch.setattr(httpx,'Client',client)

    assert probe_avalai.main()==int(status!=200)
    request,=calls
    assert request.method=='POST' and str(request.url)=='https://api.avalai.ir/v1/chat/completions'
    assert request.headers['authorization']=='Bearer aa-test-placeholder'
    assert json.loads(request.content)=={
        'model':'deepseek-v4.1-flash','messages':[{'role':'user','content':'سلام'}],'max_completion_tokens':512,
    }
    out=capsys.readouterr().out
    assert f'HTTP {status}' in out and expected in out and '01a009d5-ec91-74c2-8ffa-9eba731dfc9e' in out
    assert not any(s in out for s in ('placeholder','private-body','private-header','example.invalid'))


@pytest.mark.parametrize('pasted,expected',[
    (' \t','No key was received.'),
    ('Bearer','Input is not a single API key.'),
    ('Authorization: Basic private-value','Input is not a single API key.'),
    ('Bearer private-value\r\nX-Other: injected','Input is not a single API key.'),
    ('"private-value','Input is not a single API key.'),
    ('aa-******','Input is not a single API key.'),
])
def test_invalid_key_does_not_build_http_client(monkeypatch,capsys,pasted,expected):
    monkeypatch.setattr('builtins.input',lambda _:'SEND')
    monkeypatch.setattr(probe_avalai.getpass,'getpass',lambda _:pasted)
    monkeypatch.setattr(httpx,'Client',lambda **_:pytest.fail('created client'))

    assert probe_avalai.main()==1
    out=capsys.readouterr().out
    assert expected in out and 'No request sent.' in out
    assert 'private-value' not in out


def test_windows_dialog_cancel_never_builds_client(monkeypatch):
    def dismiss(windows_dialog):
        assert windows_dialog is True
        return None

    monkeypatch.setattr('builtins.input',lambda _:'SEND')
    monkeypatch.setattr(probe_avalai,'prompt_key',dismiss)
    monkeypatch.setattr(httpx,'Client',lambda **_:pytest.fail('created client'))
    assert probe_avalai.main(windows_dialog=True)==0
