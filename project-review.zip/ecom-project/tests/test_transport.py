from urllib.error import HTTPError

import pytest
import planner

@pytest.mark.parametrize('status',[401,402,429,None],ids=['auth','payment','rate-limit','timeout'])
def test_h1_transport_error_mapping(monkeypatch,status):
    class Opener:
        def open(self,request,timeout):
            assert request.full_url=='https://api.deepseek.com/chat/completions'
            if status is None:
                raise TimeoutError()
            raise HTTPError(request.full_url,status,'test',{},None)
    monkeypatch.setattr(planner,'build_opener',lambda *_:Opener())
    with pytest.raises(planner.ToolError,match=str(status) if status else 'مهلت'):
        planner.transport('stub',{'model':'deepseek-flash'},.5)

