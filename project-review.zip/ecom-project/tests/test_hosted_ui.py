"""Verify the hosted gate and paid button behavior without sending any network request."""
from pathlib import Path
import streamlit as st
from streamlit.testing.v1 import AppTest
import access
import planner
import store

APP=Path(__file__).parents[1]/'app.py'

def test_h1_anonymous_ui_sees_no_data_or_actions(monkeypatch):
    monkeypatch.setenv('HOSTED','1')
    monkeypatch.setenv('PROXY_TOKEN','proxy-stub')
    monkeypatch.setenv('AGENT_MODE','deepseek')
    def unavailable(*_a, **_kw):
        raise AssertionError('anonymous app touched database')
    monkeypatch.setattr(store,'connect',unavailable)
    demo=AppTest.from_file(str(APP)).run()
    demo.run()
    assert not demo.exception and demo.error
    assert not demo.button and not demo.metric and not demo.sidebar.selectbox
    assert access.actor({'X-Ecom-Identity':'manager','X-Ecom-Proxy-Token':'spoofed'}) is None

def test_h1_explicit_consent_and_rerun_do_not_charge(db,monkeypatch):
    from psycopg.conninfo import make_conninfo
    args,kwargs=store.config(test=True)
    monkeypatch.setenv('ECOM_DSN',make_conninfo(*args,**kwargs))
    monkeypatch.setenv('HOSTED','1')
    monkeypatch.setenv('PROXY_TOKEN','proxy-stub')
    monkeypatch.setenv('AGENT_MODE','deepseek')
    monkeypatch.setenv('DEEPSEEK_API_KEY','not-a-real-key')
    monkeypatch.setenv('LLM_DAILY_REQUESTS','2')
    monkeypatch.setenv('LLM_DAILY_TOKENS','34000')
    get_actor=access.actor
    headers={'X-Ecom-Identity':'manager','X-Ecom-Proxy-Token':'proxy-stub'}
    monkeypatch.setattr(access,'actor',lambda _headers,local:get_actor(headers,local))
    sent=[]
    def send(_key,body,_timeout):
        sent.append(body)
        raise planner.ToolError('پاسخ نمایشی سرویس')
    real=planner.DeepSeek
    monkeypatch.setattr(planner,'DeepSeek',lambda key,reserve,enabled:real(key,reserve,send,enabled))
    st.cache_resource.clear()
    app=AppTest.from_file(str(APP),default_timeout=30).run()
    app.radio(key='page').set_value('میز پیگیری').run()
    app.radio(key='desk_mode').set_value('دموی ساختگی کلاس').run()
    assert not app.exception and not sent
    assert not app.text_input
    assert next(b for b in app.button if b.label=='آغاز دمو').proto.disabled
    app.checkbox[0].check().run()
    assert not sent
    next(b for b in app.button if b.label=='آغاز دمو').click().run()
    assert not app.exception and len(sent)==2
    for _ in range(2): app.run()
    assert len(sent)==2
    next(b for b in app.button if b.label=='دریافت اطلاعات خطا داد').click().run()
    assert len(sent)==2
    assert db.execute('select requests,tokens from model_budget').fetchone()=={'requests':2,'tokens':34000}

