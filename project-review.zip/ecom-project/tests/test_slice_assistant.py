import pytest

import planner
from slice_assistant import Slice, analyze
import store

def test_paid_service_does_not_reserve_before_consent_role_or_key(db):
    scope=Slice('ACC-DIGI','بهمن',15,18,False)
    calls=[]
    args=dict(scope=scope,metrics=scope.metrics(db),question='pace',actor='manager',
              consent=True,enabled=True,key='local-test-key',
              reserve=lambda spend:calls.append(spend),send=lambda *_:pytest.fail('unexpected request'))
    for override in ({'actor':'observer'},{'consent':False},{'enabled':False}):
        with pytest.raises(PermissionError):
            analyze(**(args | override))
    with pytest.raises(planner.ToolError,match='کلید'):
        analyze(**(args | {'key':None}))
    assert calls==[]
    with pytest.raises(planner.ToolError,match='سقف'):
        analyze(**args)
    assert calls==[8000]

def test_only_supported_model_focus_is_rendered(db):
    scope=Slice('ACC-DIGI','بهمن',15,18,False)
    store.import_book(db)
    metrics=scope.metrics(db)
    def provider(text):
        return lambda *_:{'choices':[{'finish_reason':'stop','message':{'role':'assistant','content':text}}]}
    args=dict(scope=scope,metrics=metrics,question='pace',actor='specialist',consent=True,
              enabled=True,key='local-test-key',reserve=lambda _:True)
    for bad in ('{"focus":"coverage"}','{"focus":"sales","cause":"قطعی"}','{"focus":"order_from_store"}'):
        with pytest.raises(planner.ToolError,match='سازگار نبود'):
            analyze(**args,send=provider(bad))
    a=analyze(**args,send=provider('{"focus":"sales"}'))
    b=analyze(**args,send=provider('{"focus":"budget"}'))
    for bad in ({'choices':[{'finish_reason':'length'}]},
                {'choices':[{'finish_reason':'stop','message':{'role':'assistant','content':None}}]},
                {'choices':[{'finish_reason':'stop','message':{'role':'assistant','content':'{"focus":"sales"}',
                                                               'tool_calls':[{}]}}]}):
        with pytest.raises(planner.ToolError,match='سازگار نبود'):
            analyze(**args,send=lambda *_:bad)
    assert '۲۴۱۶' in a and 'عقب‌تر' in a and 'روند لغو و مرجوع' in a
    assert 'سهم برند' in b and 'علت اختلاف را ثابت نمی‌کند' in b

@pytest.mark.parametrize('status,detail',[(400,'درخواست تحلیل را نپذیرفت'),(401,'کلید'),(402,'اعتبار'),(403,'مجوز'),(404,'پیدا نشد'),(422,'درخواست تحلیل را نپذیرفت'),(429,'نرخ')])
def test_paid_dashboard_maps_provider_errors(db,status,detail):
    scope=Slice('ACC-DIGI','بهمن',15,18,False)
    def fail(*_):
        raise planner.ToolError('stub',status=status)
    with pytest.raises(planner.ToolError,match=detail):
        analyze(scope=scope,metrics=scope.metrics(db),question='pace',actor='manager',
                consent=True,enabled=True,key='local-test-key',reserve=lambda _:True,send=fail)


def test_dashboard_surfaces_transport_failure_without_replacement(db):
    scope=Slice('ACC-DIGI','بهمن',15,18,False)
    def broken(*_):
        raise planner.ToolError('مهلت دریافت پاسخ مدل تمام شد')
    with pytest.raises(planner.ToolError,match='مهلت'):
        analyze(scope=scope,metrics=scope.metrics(db),question='pace',actor='manager',
                consent=True,enabled=True,key='local-test-key',reserve=lambda _:True,send=broken)
