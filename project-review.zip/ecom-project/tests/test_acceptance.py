from dataclasses import replace
import json
from pathlib import Path
import subprocess
import sys
from time import perf_counter
from statistics import median

import pytest

import access
from domain import ACCOUNTS, Input, Offer, Plan, PRODUCTS, Sale, Witness, clock, ratio
from planner import DeepSeek, Offline, ToolError, Tools, validate
import readers
import store
import triage

GOLD=json.loads((Path(__file__).parents[1]/'qa/golden.json').read_text(encoding='utf-8'))
M='بهمن'; P=next(iter(PRODUCTS)); A='ACC-DIGI'; T=clock(M,1)

class Memory:
    def __init__(self,*items):
        self.items=items
    def read(self):
        yield from self.items

def test_d2_x1_reader_revision_disputes_and_rollback(db):
    store.import_book(db)
    assert tuple(ACCOUNTS)==tuple(GOLD['workbook'])
    workbook=store.metrics(db,M,15,A)['net']
    t=Input('sale','one',1,A,T,T,Sale(M,1,P,7,0,0,100000,0,0),{'batch':'first'})
    plan=Input('plan','plan-id',1,A,T,T,Plan(M,10,0),{})
    def ingest(*x): return store.ingest(db,'reader-test','memory',Memory(*x))
    def metrics(): return store.metrics(db,M,1,A,dataset='reader-test',source='memory')
    assert ingest(t,plan)[0]=={'sale:new':1,'plan:new':1}
    assert metrics()['net']==7 and metrics()['util'] is None
    assert ingest(replace(t,trace={'batch':'second'}),replace(plan,id='another-native-plan-id'))[0]=={
        'sale:duplicate':1,'plan:duplicate':1}
    t2=replace(t,revision=2,data=replace(t.data,registered=10))
    assert ingest(t2)[0]=={'sale:corrected':1}
    assert metrics()['net']==10 and metrics()['attain']==1
    assert metrics()['rows'][0]['trace']=={'batch':'first','native_id':'one'}
    assert ingest(t)[0]=={'sale:stale':1}
    assert ingest(replace(t2,data=replace(t.data,registered=50)),replace(plan,data=replace(plan.data,target=20)))[0]=={
        'sale:conflict':1,'plan:conflict':1}
    x=metrics()
    assert (x['net'],x['target'],len(x['disputed']))==(10,10,2)
    assert ratio(None,5) is None and ratio(0,5)==0 and ratio(2,0) is None
    bad,_=ingest(replace(t,account='UNKNOWN',id='bad'))
    assert bad=={'rejected':1}
    with pytest.raises(RuntimeError):
        with db.transaction():
            ingest(replace(t,id='rolled-back'))
            raise RuntimeError('injected abort after writes')
    assert metrics()['net']==10
    assert store.metrics(db,M,15,A,True)['net']==workbook
    assert not triage.cases(db)
    assert store.ingest(db,'reader-test','alternate',Memory(t))[0]=={'sale:new':1}
    assert metrics()['net']==10

def test_c1_c2_success_referral_restart_and_owner(db):
    assert triage.start(db,'manager')
    c,s=triage.queue(db)
    assert (c['account'],c['kind'],c['store'])==('ACC-OKALA','stockout','TEH-O1')
    assert (s['account'],s['kind'],s['store'])==('ACC-SNAPP','discount','TEH-S1')
    assert s['drafts'][-1]['action_code']=='review_discount'
    assert '25٪' in s['drafts'][-1]['reason_fa'] and '20٪' in s['drafts'][-1]['reason_fa']
    d=c['drafts'][-1]
    assert d['action_code']=='check_store_supply' and '800' in d['reason_fa']
    assert {e['id'] for e in d['evidence']}=={'DEMO-O1@1','DEMO-O1-W@1','PERF-ACC-OKALA'}
    assert triage.decide(db,triage.DEMO,c['id'],d['id'],'manager','edit','مسئول فروشگاه شاهد را بررسی کند.')
    assert triage.decide(db,triage.DEMO,c['id'],d['id'],'manager','approve')
    assert not triage.decide(db,triage.DEMO,c['id'],d['id'],'manager','approve')
    assert triage.advance(db,'manager','orderable')
    c=triage._case(db,triage.DEMO,c['id'])
    assert c['status']=='recovery_verified' and c['latest']['orderable']
    assert len(c['referrals'])==1 and c['referrals'][0]['text']=='مسئول فروشگاه شاهد را بررسی کند.'
    assert c['referrals'][0]['original']==d['next_action_fa']
    with pytest.raises(PermissionError): triage.close(db,triage.DEMO,c['id'],'manager')
    assert triage.close(db,triage.DEMO,c['id'],'specialist')
    program="""import json,store,triage
with store.connect(test=True) as db:
    c=triage._case(db,'class-demo','CASE-00001')
    print(json.dumps([c['status'],c['owner'],[x['type'] for x in c['events']]]))
"""
    status,owner,events=json.loads(subprocess.check_output([sys.executable,'-c',program]))
    assert (status,owner)==('closed','specialist') and events[-2:]==['drafted','closed']

def test_c3_error_replay_and_reset_isolation(db):
    store.import_book(db)
    triage.start(db,'manager')
    c,_=triage.queue(db)
    before=c['drafts'][-1]
    triage.decide(db,triage.DEMO,c['id'],before['id'],'manager','reject')
    assert triage.advance(db,'manager','error')
    c=triage._case(db,triage.DEMO,c['id'])
    assert c['status']=='open' and not c['referrals'] and c['latest']['status']=='error'
    latest=c['drafts'][-1]
    assert latest['action_code']=='verify_source'
    assert [t['tool'] for t in before['trace']][:2]==['observation','evidence']
    assert [t['tool'] for t in latest['trace']][:2]==['observation','history']
    snap=triage.cases(db)
    assert not triage.advance(db,'manager','error') and triage.cases(db)==snap
    with pytest.raises(ValueError): triage.advance(db,'manager','orderable')
    with pytest.raises(ValueError): triage.close(db,triage.DEMO,c['id'],'specialist')
    triage.reset(db,'manager')
    assert not triage.cases(db) and store.metrics(db,M,15,A)['net']==2416

def test_c4_scope_time_policy_and_episode(db):
    o=dict(account=A,product=P,offer='offer',store='store',location='loc',time=30,reference=100000,price=80000)
    broad=dict(id='p',time=0,available=0,approved=True,account=A,product='*',offer='*',
               location='*',start=0,end=100,cap='20',priority=1)
    assert not triage.discount(o,[broad])['breach']
    assert triage.discount(dict(o,price=79999),[broad])['breach']
    scoped=dict(broad,id='specific',product=P,offer='offer',location='loc',start=28,end=31,cap='25',priority=2)
    assert not triage.discount(dict(o,price=75000),[broad,scoped])['breach']
    for mismatch in (dict(o,price=75000,time=32),dict(o,price=75000,location='other')):
        assert triage.discount(mismatch,[broad,scoped])['breach']
    assert triage.discount(o,[scoped,dict(scoped,id='conflict',cap='22')])['reason']=='conflicting-policy'
    assert triage.discount(dict(o,reference=0),[broad])['reason']=='unknown-price'
    dataset='edge'; source='memory'
    def event(id,t,seen,orderable=False,covered=True,shop='store',wt=None,mapped=True):
        x=Input('offer',id,1,A,t,t,Offer(P,'offer',shop,'loc','ok',covered,mapped,orderable,
                                       witness=id+'-w'),{})
        w=Input('witness',id+'-w',1,None,t,t if wt is None else wt,Witness(id,'شاهد'),{})
        store.ingest(db,dataset,source,Memory(x,w))
        s=dict(triage.EMPTY,clock=seen)
        candidates=triage._facts(store.latest(db,dataset,'offer',seen,source))
        if any(v['id']==id for v in candidates):
            with store.locked(db,dataset):
                triage._apply(db,dataset,source,next(v for v in candidates if v['id']==id),s,Offline())
                triage._save_state(db,dataset,s)
    for args in [('stale',10,16),('future',23,22),('witness-later',21,22,False,True,'store',23),
                 ('no-coverage',22,22,False,False),('uncertain',22,22,False,True,'store',None,False)]:
        event(*args)
    assert all(not c['confirmed'] for c in triage.cases(db,dataset))
    event('fresh',24,29)
    c=triage.cases(db,dataset)[0]
    assert c['confirmed'] and c['latest']['fresh']
    event('mismatch',25,29,True,True,'different-store')
    event('late',23,29,True)
    assert triage.cases(db,dataset)[0]['latest']['id']=='fresh'
    event('recovered',30,30,True)
    assert triage.close(db,dataset,c['id'],'specialist')
    event('new',31,31)
    assert [c['status'] for c in triage.cases(db,dataset)]==['closed','open']

class Fake:
    def __init__(self,fail=None):
        self.sent=[]; self.fail=fail
    def __call__(self,key,body,timeout):
        assert timeout>0
        self.sent.append(json.loads(json.dumps(body)))
        if self.fail: raise ToolError(self.fail)
        msgs=body['messages']
        info=json.loads(msgs[1]['content'].split(' Return')[0])
        reads=[m for m in msgs if m['role']=='tool']
        first='observation'
        if not reads: tool=first
        else:
            o=json.loads(reads[0]['content'])
            plan=['observation','history'] if o['status']=='error' else ['observation','evidence',
                 'performance' if info['kind']=='stockout' else 'policy']
            tool=plan[len(reads)] if len(reads)<len(plan) else None
        if tool:
            m={'tool_calls':[{'id':f'call{len(reads)}','function':{'name':tool,'arguments':'{}'}}]}
        else:
            from planner import ACTIONS
            code='verify_source' if o['status']=='error' else ('check_store_supply' if info['kind']=='stockout'
                   else 'review_discount')
            e=[dict(id=x['id'],time=x['time']) for r in reads for x in
               ([json.loads(r['content'])] if r['content'].startswith('{') else json.loads(r['content'])) if 'id' in x]
            m={'content':json.dumps(dict(case_id=info['case_id'],priority='high',action_code=code,
                 next_action_fa=ACTIONS[code],owner_role='specialist',reason_fa='شاهد همین عرضه بررسی شد.',
                 evidence=e,missing=['شاهد تازه'] if code=='verify_source' else []))}
        return {'choices':[{'message':m}]}

def test_a1_host_validation_adapter_and_deferrals(db):
    contexts=[]
    class Capture:
        def run(self,ctx):
            contexts.append(ctx)
            return Offline().run(ctx)
    triage.start(db,'manager',Capture())
    triage.advance(db,'manager','error',Capture())
    o,s,error=contexts
    assert o['case_id']==error['case_id']
    fake=Fake()
    online=DeepSeek('dummy',lambda _:True,fake,True)
    assert online.run(o)['status']=='validated'
    assert online.run(s)['action_code']=='review_discount'
    assert [x['tool'] for x in online.run(error)['trace']]==['observation','history']
    tools=Tools(o); tools.read('observation'); tools.read('evidence')
    d={k:v for k,v in Offline().run(o).items() if k not in ('mode','status','trace')}
    for change in ({'action_code':'close'},{'evidence':[]},{'evidence':[{'id':'foreign','time':0}]},
                   {'evidence':[{'id':'DEMO-O1@1','time':o['as_of']+1}]},{'reason_fa':[] }):
        assert validate(dict(d,**change),tools,'offline')['status']=='deferred'
    assert Offline().run(dict(o,evidence=None))['status']=='deferred'
    tiny=Tools(o,1); tiny.read('observation')
    with pytest.raises(ToolError): tiny.read('evidence')
    stopped=DeepSeek('dummy',lambda _:False,fake,True).run(o)
    assert stopped['status']=='deferred' and 'سقف' in stopped['reason_fa']

def test_a2_compare_with_fixed_baseline(db):
    expected=GOLD['demo']
    stats={x:dict(top=0,action=0,evidence=0,deferral=0) for x in ('offline','fixed')}
    Capture=type('Capture',(),{'run':lambda self,ctx:(self.contexts.update({ctx['case_id']:ctx}) or Offline().run(ctx))})
    for scenario in ('initial','error','orderable'):
        triage.reset(db,'manager')
        capture=Capture(); capture.contexts={}
        triage.start(db,'manager',capture)
        if scenario!='initial': triage.advance(db,'manager',scenario,capture)
        c=triage.queue(db)
        fixed=sorted(c,key=lambda x:(x['kind']!='stockout',x['id']))
        for mode,ordered in [('offline',c),('fixed',fixed)]:
            result=stats[mode]
            result['top']+=ordered[0]['kind']==expected['top'][scenario]
            for item in ordered:
                kind=item['kind']
                ctx=capture.contexts[item['id']]
                if mode=='offline':
                    d=item['drafts'][-1]
                    code=d['action_code']; ids={e['id'] for e in d['evidence']}
                else:
                    code={'stockout':'check_store_supply','discount':'review_discount'}[kind]; ids={ctx['observation']['id']}
                    if ctx['evidence']: ids.add(ctx['evidence']['id'])
                    if kind=='discount' and 'id' in ctx['policy']: ids.add(ctx['policy']['id'])
                right=expected[scenario][kind]
                result['action']+=code==right
                result['evidence']+=bool(code==right and ctx['observation']['id'] in ids and
                     (code=='verify_source' or (ctx['evidence'] and ctx['evidence']['id'] in ids)) and
                     (kind!='discount' or ctx['policy']['id'] in ids))
                if right=='verify_source': result['deferral']+=code==right
    assert stats=={'offline':{'top':3,'action':6,'evidence':6,'deferral':1},
                   'fixed':{'top':1,'action':4,'evidence':4,'deferral':0}}
    print('A2',stats,'denominators: top=3 action=6 evidence=6 deferral=1; DE-MO-O3@1 → verify_source')

def test_p1_import_warm_queries(db,monkeypatch):
    start=perf_counter()
    counts,_=store.import_book(db)
    initial=perf_counter()-start
    def fail(*a,**kw):
        pytest.fail('warm dashboard tried to parse the workbook')
    monkeypatch.setattr(readers,'load_workbook',fail)
    samples=[]
    for a in (*ACCOUNTS,None,*ACCOUNTS):
        start=perf_counter()
        out=store.metrics(db,M,15,a)
        samples.append(perf_counter()-start)
        assert len(out['rows'])==(45 if a else 135)
    print(f'P1 import={initial:.4f}s warm_median={median(samples)*1000:.2f}ms samples={len(samples)} sales={counts["sale:new"]}')

def test_h1_hosted_gate_provider_failures_replay_and_budget(db,monkeypatch):
    monkeypatch.setenv('HOSTED','1')
    monkeypatch.setenv('PROXY_TOKEN','test-placeholder')
    assert access.actor({'X-Ecom-Identity':'manager'},'manager') is None
    assert access.actor({'X-Ecom-Proxy-Token':'test-placeholder','X-Ecom-Identity':'observer'})=='observer'
    fake=Fake()
    online=DeepSeek('no-real-key',lambda _:True,fake,True)
    with pytest.raises(PermissionError): triage.start(db,None,online)
    with pytest.raises(PermissionError): triage.reset(db,'observer')
    assert not fake.sent
    store.import_book(db)
    triage.review_workbook(db,'manager',M,15,18)
    assert not fake.sent
    triage.start(db,'manager',online)
    count=len(fake.sent)
    assert count==8
    assert not triage.start(db,'manager',online)
    assert len(fake.sent)==count
    s=json.dumps(fake.sent,ensure_ascii=False)
    assert not any(x in s for x in ('no-real-key','2416','SALE-','fixture://','شاهد ساخته'))
    c=triage.queue(db)[0]
    with pytest.raises(PermissionError):
        triage.decide(db,triage.DEMO,c['id'],c['drafts'][-1]['id'],'observer','approve')
    with pytest.raises(PermissionError): triage.close(db,triage.DEMO,c['id'],'observer')
    connect=lambda:store.connect(test=True)
    assert access.model_budget(connect,1,17000)(17000)
    assert not access.model_budget(connect,1,17000)(17000)
    for status in ('401','402','429','timeout'):
        triage.reset(db,'manager')
        fake=Fake('خطای سرویس مدل '+status)
        online=DeepSeek('dummy',lambda _:True,fake,True)
        triage.start(db,'manager',online)
        c=triage.queue(db)[0]
        assert c['status']=='open' and not c['referrals']
        assert (c['drafts'][-1]['mode'],c['drafts'][-1]['status'])==('deepseek','deferred')
        assert status in c['drafts'][-1]['reason_fa']

