"""Smoke the portable launcher and reopen a real Streamlit process on Windows/Unix."""
import os
from pathlib import Path
import socket
import subprocess
import sys
from time import monotonic, sleep
from urllib.request import ProxyHandler, build_opener

import store

ROOT=Path(__file__).parents[1]
M='بهمن'; A='ACC-DIGI'; P='PRD-CLEAR-450G'

def test_p1_launcher_process_restart(db,monkeypatch):
    from psycopg.conninfo import make_conninfo
    args,kwargs=store.config(test=True)
    monkeypatch.setenv('ECOM_DSN',make_conninfo(*args,**kwargs))
    monkeypatch.delenv('HOSTED',raising=False)
    link=build_opener(ProxyHandler({}))
    def boot():
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0))
            port=sock.getsockname()[1]
        # Start Streamlit via the same command builder the launcher uses, without orphaning a child.
        from launch import streamlit_command
        proc=subprocess.Popen(streamlit_command(port,True),cwd=ROOT,stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL,env=dict(os.environ,STREAMLIT_BROWSER_GATHER_USAGE_STATS='false'))
        try:
            until=monotonic()+20
            while monotonic()<until and proc.poll() is None:
                try:
                    with link.open(f'http://127.0.0.1:{port}/_stcore/health',timeout=.5) as r:
                        if r.read().strip()==b'ok':
                            return proc
                except OSError:
                    sleep(.15)
            raise AssertionError('Streamlit never became healthy')
        except BaseException:
            stop(proc)
            raise
    def stop(proc):
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(8)
            except subprocess.TimeoutExpired:
                proc.kill(); proc.wait(8)
    app=boot()
    try:
        store.import_book(db)
        vals=(20,0,0,100000,0,0)
        store.save_manual(db,M,16,A,P,vals,0)
        store.save_manual(db,M,16,A,P,(18,*vals[1:]),1,True)
    finally:
        stop(app)
    restarted=boot()
    try:
        assert app.poll() is not None
        with store.connect() as reopened:
            assert store.metrics(reopened,M,16,A,True)['net']==2434
            assert store.metrics(reopened,M,16,A,False)['net']==2416
    finally:
        stop(restarted)

def test_launcher_uses_a_free_port_when_preferred_is_occupied(monkeypatch):
    import launch
    monkeypatch.setattr(launch,'config',lambda:None)
    seen={}
    def start(command,**kwargs):
        seen['command']=command
        port=int(command[command.index('--server.port')+1])
        assert port!=preferred
        assert command[command.index('--browser.serverPort')+1]==str(port)
        assert command[command.index('--server.showEmailPrompt')+1]=='false'
        with socket.socket() as check:
            check.bind(('127.0.0.1',port))
        return 0
    monkeypatch.setattr(launch.subprocess,'call',start)
    with socket.socket() as occupied:
        occupied.bind(('127.0.0.1',0))
        occupied.listen()
        preferred=occupied.getsockname()[1]
        monkeypatch.setattr(sys,'argv',['launch.py','--port',str(preferred)])
        assert launch.main()==0
        assert seen['command']


def test_avalai_launcher_passes_credentials_only_to_local_demo(monkeypatch):
    import launch
    monkeypatch.setattr(launch,'config',lambda:None)
    monkeypatch.setattr(launch,'available_port',lambda port:port)
    monkeypatch.setattr(sys,'argv',['launch.py','--avalai-demo','--headless'])
    monkeypatch.setattr(launch,'read_avalai_settings',lambda:None)
    started=[]
    def start(command,*,env,**kwargs):
        started.append(command)
        assert 'aa-test-value' not in ' '.join(command)
        assert env['ECOM_LOCAL_AVALAI_BASE_URL']=='https://api.avalai.ir/v1'
        assert env['ECOM_LOCAL_AVALAI_TOKEN']=='aa-test-value'
        assert env['SLICE_AGENT']=='off' and env['AGENT_MODE']=='offline'
        return 0
    monkeypatch.setattr(launch.subprocess,'call',start)
    assert launch.main()==0 and not started
    monkeypatch.setattr(launch,'read_avalai_settings',lambda:('https://api.avalai.ir/v1','aa-test-value'))
    assert launch.main()==0 and len(started)==1
