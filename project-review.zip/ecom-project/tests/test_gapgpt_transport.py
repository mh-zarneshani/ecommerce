import io
import json
import httpx

import pytest

import planner


def mock_gateway(monkeypatch, handler):
    monkeypatch.setattr(planner,'_gapgpt_client',lambda timeout:httpx.Client(
        timeout=timeout,transport=httpx.MockTransport(handler),follow_redirects=False))


def test_gapgpt_dashboard_transport_targets_only_the_configured_gateway(monkeypatch):
    requests=[]
    def handler(request):
        requests.append((str(request.url),request.method,request.headers['authorization'],
                         json.loads(request.content),request.extensions['timeout']['read']))
        return httpx.Response(200,json={'choices':[]})
    mock_gateway(monkeypatch,handler)
    def opener(handler):
        assert isinstance(handler,planner.NoRedirect)
        class Opener:
            def open(self,request,timeout):
                requests.append((request.full_url,request.get_method(),request.get_header('Authorization'),
                                 json.loads(request.data),timeout))
                return io.BytesIO(b'{"choices":[]}')
        return Opener()
    monkeypatch.setattr(planner,'build_opener',opener)
    body={'model':'deepseek-flash','messages':[{'role':'user','content':'test summary'}]}
    dashboard={'model':'gapgpt-deepseek-v4.1-flash','messages':[{'role':'user','content':'آزمون'}],'max_tokens':512}
    assert planner.gapgpt_transport('example-token',dashboard,3)=={'choices':[]}
    assert planner.transport('demo-token',body,4)=={'choices':[]}
    assert requests==[
        ('https://api.gapgpt.app/v1/chat/completions','POST','Bearer example-token',dashboard,3),
        ('https://api.deepseek.com/chat/completions','POST','Bearer demo-token',body,4),
    ]


@pytest.mark.parametrize('body,reason',[
    (b'{"error":{"param":"messages","message":"echoed private material"}}','messages'),
    (b'{"error":{"code":"model_not_found","message":"echoed private material"}}','model'),
    (b'{"error":{"param":"echoed private material","message":"echoed private material"}}',None),
    (b'<html>echoed private material</html>',None),
])
def test_gapgpt_400_classifies_only_known_fields(monkeypatch,body,reason):
    mock_gateway(monkeypatch,lambda _:httpx.Response(400,content=body))
    with pytest.raises(planner.ToolError) as error:
        planner.gapgpt_transport('placeholder',{'model':'stub'},3)
    assert error.value.status==400 and error.value.reason==reason
    assert 'echoed private material' not in str(error.value)


@pytest.mark.parametrize('status',[400,200])
def test_gapgpt_handles_truncated_chunked_body_without_retry(monkeypatch,status):
    class Truncated(httpx.SyncByteStream):
        def __iter__(self):
            yield b'private payload'
            raise httpx.RemoteProtocolError('incomplete chunk')
    requests=[]
    def handle(request):
        requests.append(request)
        return httpx.Response(status,stream=Truncated())
    mock_gateway(monkeypatch,handle)
    with pytest.raises(planner.ToolError) as error:
        planner.gapgpt_transport('placeholder',{'model':'stub'},3)
    assert error.value.status==(400 if status==400 else None)
    assert error.value.reason=='incomplete'
    assert 'private payload' not in str(error.value)
    assert len(requests)==1


def test_gapgpt_does_not_follow_a_redirect(monkeypatch):
    requests=[]
    def handle(request):
        requests.append(str(request.url))
        return httpx.Response(307,headers={'Location':'https://example.org/'})
    mock_gateway(monkeypatch,handle)
    with pytest.raises(planner.ToolError) as error:
        planner.gapgpt_transport('placeholder',{'model':'stub'},3)
    assert error.value.status==307
    assert requests==['https://api.gapgpt.app/v1/chat/completions']


@pytest.mark.parametrize('ids,found',[(['gapgpt-deepseek-v4.1-flash'],True),(['deepseek-other'],False)])
def test_gapgpt_catalog_check_sends_only_get(monkeypatch,ids,found):
    seen=[]
    def handle(request):
        seen.append((str(request.url),request.method,request.content,request.headers['authorization']))
        return httpx.Response(200,json={'data':[{'id':model} for model in ids]})
    mock_gateway(monkeypatch,handle)
    assert planner.gapgpt_check_model('placeholder') is found
    assert seen==[('https://api.gapgpt.app/v1/models','GET',b'','Bearer placeholder')]


def test_catalog_launcher_has_no_database_or_streamlit_dependency(monkeypatch,capsys):
    import sys
    import launch

    monkeypatch.setattr(sys,'argv',['launch.py','--check-gapgpt'])
    monkeypatch.setattr(launch,'config',lambda:pytest.fail('opened the database configuration'))
    monkeypatch.setattr(launch.subprocess,'call',lambda *_a,**_k:pytest.fail('started Streamlit'))
    monkeypatch.setattr(launch.getpass,'getpass',lambda prompt:' Bearer placeholder ')
    def check(key):
        assert key=='placeholder'
        return True
    monkeypatch.setattr(planner,'gapgpt_check_model',check)
    assert launch.main()==0
    shown=capsys.readouterr().out
    assert 'HTTP 200' in shown and 'placeholder' not in shown


@pytest.mark.parametrize('answers,status',[
    ([''],None),(['SEND'],None),(['1','cancel'],None),(['2','send'],None),
    (['1','SEND'],200),(['2','SEND'],400),(['1','SEND'],307),
])
def test_model_probe_matches_support_sample_without_logging_raw_body(monkeypatch,answers,status,capsys):
    import sys
    import launch

    monkeypatch.setattr(sys,'argv',['launch.py','--probe-gapgpt'])
    replies=iter(answers)
    monkeypatch.setattr('builtins.input',lambda _:next(replies))
    monkeypatch.setattr(launch,'config',lambda:pytest.fail('opened the database'))
    if status is None:
        monkeypatch.setattr(launch,'read_model_key',lambda _:pytest.fail('read a key before consent'))
    else:
        monkeypatch.setattr(launch,'read_model_key',lambda _:'placeholder')
    calls=[]
    import json
    settings=[]
    def handle(request):
        calls.append((str(request.url),request.method,request.headers['authorization'],
                      request.extensions['timeout'],json.loads(request.content)))
        payload=({'choices':[{'message':{'content':'سلام'}}]} if status==200
                 else {'error':{'code':'model_not_found','param':'model','type':'private-type',
                                'message':'Model unavailable. Bearer placeholder; password="private value"'},
                       'raw':'private-payload'})
        return httpx.Response(status,json=payload,headers={
            'X-Private':'private-header','Location':'https://example.invalid/'})
    real_client=httpx.Client
    def client(**opts):
        settings.append(opts)
        return real_client(transport=httpx.MockTransport(handle),**opts)
    monkeypatch.setattr(httpx,'Client',client)
    assert launch.main()==int(status is not None and status!=200)
    assert len(calls)==int(status is not None)
    shown=capsys.readouterr().out
    assert not any(word in shown for word in ('placeholder','private value','private-type',
                                              'private-payload','private-header','example.invalid'))
    if status==400:
        assert 'error.code: model_not_found' in shown and 'error.param: model' in shown
        assert 'error.message: Model unavailable.' in shown and '[حذف شد]' in shown
    if calls:
        assert settings==[dict(timeout=60,trust_env=answers[0]=='1',verify=True,follow_redirects=False)]
        assert calls==[('https://api.gapgpt.app/v1/chat/completions','POST','Bearer placeholder',
            dict.fromkeys(('connect','read','write','pool'),60),
            {'model':'gapgpt-deepseek-v4.1-flash',
                    'messages':[{'role':'system','content':'You are a helpful assistant.'},
                                {'role':'user','content':'سلام'}],
                    'max_tokens':512},
        )]
        assert f'HTTP {status}' in shown
    else:
        assert not settings and 'لغو شد' in shown


@pytest.mark.parametrize('content,label',[
    (b' \n','بدنهٔ پاسخ خالی'),
    (b'<html>private-text</html>','بدنهٔ پاسخ JSON نیست'),
    (b'{"error":{"code":"bad"}}','ساختار JSON خطا ناقص'),
    (b'{"error":','بدنهٔ JSON ناقص'),
    (None,'خواندن بدنه قطع شد'),
])
def test_model_probe_keeps_http_400_and_classifies_body(monkeypatch,content,label,capsys):
    import launch

    class Interrupted(httpx.SyncByteStream):
        def __iter__(self):
            yield b'{"error":'
            raise httpx.RemoteProtocolError('private-text')

    replies=iter(['2','SEND'])
    monkeypatch.setattr('builtins.input',lambda _:next(replies))
    monkeypatch.setattr(launch,'read_model_key',lambda _:'placeholder')
    calls=[]
    def handle(request):
        calls.append(request)
        if content is None:
            return httpx.Response(400,stream=Interrupted())
        return httpx.Response(400,content=content)
    real_client=httpx.Client
    monkeypatch.setattr(httpx,'Client',lambda **opts:real_client(transport=httpx.MockTransport(handle),**opts))
    assert launch.probe_gapgpt()==1
    shown=capsys.readouterr().out
    assert 'HTTP 400' in shown and label in shown
    assert 'private-text' not in shown and len(calls)==1
