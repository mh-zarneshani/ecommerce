@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
call "%~dp0Ensure-Windows-Python.cmd"
if errorlevel 1 goto finish
"%ECOM_PY%" launch.py --check-gapgpt
:finish
set "CHECK_RESULT=%ERRORLEVEL%"
pause
exit /b %CHECK_RESULT%
